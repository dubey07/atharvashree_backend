const url = "https://res.cloudinary.com/dc02cdybp/image/upload/v1711566690/AtharvaShree/wkfho58osa3je2plx4yt.jpg";

const temp = url.split("/");
console.log('temp: ', temp);